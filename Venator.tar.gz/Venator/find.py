import whois

dominio = input("type host: ")
consu_whois = whois.whois(dominio)

print(consu_whois.text)
