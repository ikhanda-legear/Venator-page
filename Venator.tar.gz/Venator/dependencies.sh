#!/bin/bash
apt install build-essential
pip install python-whois
