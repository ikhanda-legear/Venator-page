require 'socket'
require 'timeout'
print "IP/Address : "
ip = gets.chomp

ports = 24..1080
ports.each do |scan|
begin
Timeout::timeout(10){TCPSocket.new("#{ip}", scan)}
rescue
puts "closed : #{scan}"
else
puts "open : #{scan}"
end
end
