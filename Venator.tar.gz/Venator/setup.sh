#!/bin/bash

case $1 in
    '--help') echo 'you asked for help'
	      echo '--ip   <ip scan host>'
	      echo '--port <port scanner>'
	      echo '--malwares  <malware generator>'
	      echo '--update   <update tool for new options and exploit>'
	      echo '--info     <tool information>'
	      echo '--find     <domain information>'
	      echo '-sql-bypass <bypass password sql injection>';;

    '--ip') echo '[*] ip information'
	    echo 'please use [./ip] for use this information';;

    '--port') echo '[*] port scan'
	      ruby port.rb;;

    '--find') echo '[*] find'
	      python find.py;;

    '-sql-bypass') echo '[*] sql injection bypass'
		   cat sql-bypass;;

    '--malware') echo '[*] malware'
		 echo '[--all-list-malware] for all malware'
		 echo '[--malware-win] malware for windows'
		 echo '[--malware-nux] malware for linux'
		 echo '[--malware-mac] malware for macOS'
		 echo '         *example to use: '
		 echo './setup.sh --all-list-malware'
		 echo './setup.sh --malware-win'
		 echo './setup.sh --malware-nux'
		 echo './setup.sh --malware-mac';;
		 
		 

    

   

    *) echo 'please use [--help] for options'
    exit 1;;
esac

	      
	      
	      
